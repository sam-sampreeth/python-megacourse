meals = ['pizza', 'dal-chawal', 'burger']
for shit in meals:
    print(shit)
print("end")
